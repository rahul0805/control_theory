function x_dot = casea(t,x)
A = [0,1; -40, -4];
x_dot = A*x;
end

