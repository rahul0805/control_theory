function x_dot = ref_linear(t,x)
p = 10;
v = -0.2;
x_dot = [0;0;v;0];
end

